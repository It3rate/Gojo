# Designs from the training population

The sheet shows twenty packed machines that competed in wave one. Each program runs twice using the same seed bit, clock phase and five executed cells. The two rows change the bound extents and period. All marks were written by the machine. Scaling to fit the page is a display operation.

[Printable vector sheet](Sampler.svg) · [Compact contact sheet](Sampler.png) · [Explore individual strokes, events and scores](Explore.html).

## How the machines were selected

We considered only the complete-objective evolutionary histories, across the four training replicates of each brief. Within a replicate every repeated occurrence of the same packed bytes had the same score and criterion profile. We collapsed those duplicates, then gave each observed replicate equal weight. A program's aggregate only covers replicates where it actually occurred. Each brief retained the first quarter of distinct programs by mean training utility, rounded up. The first selection was its highest scorer. The next three maximized the minimum distance from any earlier choice under that brief. Distance is the mean absolute difference of training criteria within each perspective, then an equal average over the six perspectives. Equal distances break by higher aggregate training utility, then byte string. We selected in rounds through the frozen brief order and used each byte string once overall.

The two display calibrations are (A=2, B=1, pitch=6) and (A=3, B=4, pitch=7), both with phase zero, seed one, five cells. Selection was sealed before these runs. The sampler uses training histories and these two public realizations. It inspects no reserve outcomes. The spans and projection differ between the two displays. They have been fitted independently.

Training utility in each sheet caption is the averaged history score used in selection. The gallery's utility and individual criteria are recomputed after the particular displayed realization. A missing criterion is open and earns no utility credit. Different numeric profiles can draw coincident geometry. Selection demonstrates that the population contains other executable structures; neither its utility nor its diversity certifies aesthetic preference.

[Inputs and hashes](selection-design.json) · [Training scores, profiles and trial provenance](selected.json) · [Native drawing traces](native-traces.json).

The 40 displayed runs have 38 distinct normalized geometric supports under the sheet's segment comparison; it removes exact duplicate segments, translation and uniform scale. Different subdivisions can still distinguish two entries.
