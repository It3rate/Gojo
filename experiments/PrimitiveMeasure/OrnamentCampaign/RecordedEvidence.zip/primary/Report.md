# First local ornament tournament

The frozen programs improved infill and mirror utility on unfamiliar rails. For balance, full-grammar random search beat evolution on average. Seam repair was unreliable. A useful wire and a useful method for *finding* that wire are separate experimental findings.

Registration: `D2CD16527AA2BAE97384818476662E64CCCA1866A3A1848517BEFBB07E7956FF`. Winner lock: `CAB7FAB1FDDC63B1A970CA4AD9A3BE95419442B4323346233158491B9E0CBBB7`. The reserve outcomes were unopened for this report.

The primary competition charged 327,680 proposals across 80 populations. It executed 10,485,760 training episodes on 32-example banks, then used validation to lock one finalist per population. The paired blind table contains 59,904 machine/case/condition rows plus their idle comparisons. Replicates and reflected siblings share evidence. They do not represent that many independent motifs.

There were 240 preregistered comparisons. All 24 zero-budget controls passed. Among 216 substantive predictions, 125 were supported, 11 were contrary, and 80 were inconclusive under the frozen margins and grouped rules.

## Blind utility above the same seed without edits

Means are differences on each brief's own 0–1000 score. The scores of different briefs are not interchangeable physical quantities.

| Specialist brief | Fixed wiring | Open loop | Full random | Evolved | Mixed evolved |
| --- | ---: | ---: | ---: | ---: | ---: |
| balance | +24.8 | +31.9 | +72.6 | +57.2 | +18.0 |
| infill | +43.4 | +205.3 | +208.3 | +232.8 | +76.2 |
| mirror | -3.6 | +0.0 | +134.7 | +140.0 | -7.6 |
| seam | +0.0 | +0.0 | -4.3 | +4.7 | -13.3 |

| Evolved specialist | Improved | Tied | Regressed | Exact final |
| --- | ---: | ---: | ---: | ---: |
| balance | 455 | 76 | 45 | 15 |
| infill | 502 | 66 | 8 | 4 |
| mirror | 426 | 142 | 8 | 57 |
| seam | 55 | 407 | 114 | 62 |

## Predictions and search history

| Mechanism | Supported | Inconclusive | Contrary | Mean left minus right |
| --- | ---: | ---: | ---: | ---: |
| structure | 14 | 9 | 1 | +92.5 |
| channel | 10 | 13 | 1 | +49.4 |
| selection | 3 | 19 | 2 | +5.9 |
| cut | 17 | 5 | 2 | +70.4 |
| freeze | 9 | 15 | 0 | +8.7 |
| flip | 23 | 0 | 1 | +194.0 |
| clock | 22 | 0 | 2 | +163.7 |
| hide | 17 | 6 | 1 | +111.1 |
| stock | 10 | 13 | 1 | +38.2 |
| zero-budget | 24 | 0 | 0 | +0.0 |

The relation predicted differs by cell. A supported equivalence is not an advantage for the left arm. A paired cut or inversion tests a *particular* frozen machine. A comparison with open-loop/random tests different machines from different searches. The live-versus-frozen contrast was much weaker than the live-versus-inverted contrast. Using a wire need not imply adaptation to a newly disturbed rail.

| Search method | Mean distinct genomes per population | Mean distinct observed behaviors per population |
| --- | ---: | ---: |
| parameter | 4096.0 | 292.7 |
| open | 4082.6 | 980.0 |
| random | 4096.0 | 1481.3 |
| evolve | 3406.4 | 817.1 |

Behavior here is a training-bank fingerprint of final patterns and edit counts. Different bytes can yield the same behavior, and more diversity alone need not mean better performance.

## A small machine and its failure

Mirror replicate 3, program `0104C2004900244374`, retained one sensor row meaning “the reflected site is occupied and this site is empty.” Its writer passes that pulse into a stock-to-site passage. On `test-window-10`, ordinary view, it added the five missing reflections and reached 1,000 from 500. Disconnecting the signal left the score at 500. A sensor frozen on the initial pattern also reached 1,000, needing ten attempts rather than five. Thus this example establishes a useful correspondence, but updated sensing was not necessary for its final picture.

On `test-reflected-05`, perturbed view, external ink appeared at site 3 of a 34-site ring. The very same live rule mirrored the disturbance to site 30. Its score was 857 against 929 with frozen sensing. Both repaired every original missing mirror. The learned rule mirrors visible ink and has no evidence distinguishing a valuable new mark from an accident in this case.

For seam replicate 0 on `test-comb-02` ordinary view, the seed was already at 1,000. One live edit lowered utility to 800; a cut preserved 1,000. Aggregate results include these regressions.

## Two-axis transfer

There are 8,064 fabric observations. The six small orthogonal glyph-like seeds and their projected strip inputs were supplied. The horizontal and vertical machines were trained on one-dimensional balance and infill. The crossing laws were supplied separately. The predicted checks below test that specific composition.

| Prediction | Verdict | Observation |
| --- | --- | --- |
| F1 | supported | protected ink and stock conservation over all rows |
| F2 | supported | 1152 disconnected rows |
| F3 | supported | 6/6 families admit an OR mark despite an unknown vertical port |
| F4 | supported | 6/6 families exceed 20% changed outputs: {'cross': 0.44, 'e': 0.5, 'h': 0.96, 'ladder': 0.96, 't': 0.5, 'u': 1} |
| F5 | supported | 5/6 families exceed 20% changed outputs: {'cross': 0.5, 'e': 0.67, 'h': 0.5, 'ladder': 0, 't': 0.5, 'u': 0.5} |
| F6 | contrary | mean reduction in mirror mismatches by seed: {'cross': -1.48, 'e': -0.9, 'h': -5.21, 'ladder': -4.85, 't': -2.08, 'u': -5.38} |
| F7 | supported | 6/6 families exceed 20% changed outputs on exchanging OR and XOR |
| F8 | supported | 4032 matched allocations |

## Verification and limits

All 2,304 cold program/input replays in a fresh directory produced exactly the same outcomes, including trace hashes, as the independent reference execution. Wall times on this machine are in [the timing log](timing.log). They are not portable performance claims.

This study searches a bounded local grammar with one to four Boolean rows per owner. The grammar supplies local gap, direction, goal and mirror observations and the allowed edit passages. The search chooses how to connect and use them. It does not learn those input senses, a general aesthetic critic, or arbitrary two-dimensional drawing.

[Browse before/after examples and fabric outputs](Gallery.html). [Full prediction verdicts](test/hypotheses.csv) · [paired parent comparisons](test/groups.csv) · [all blind outcomes](test/cases.csv) · [packed winning programs](frozen.json) · [scientific protocol](manifest/ScienceProtocol.md).
