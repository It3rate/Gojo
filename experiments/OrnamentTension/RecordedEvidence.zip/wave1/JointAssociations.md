# Which joint sequences accompanied a better result?

We replayed the same frozen machine on the same physical basis with live feedback and with its actuators silenced. A sequence contributes only when it appears in exactly one member of a pair. Its signed difference is that member’s broad utility minus the other member’s utility. We averaged within each calibration parent, then across parents. These are retrospective associations. The intervention can alter many strokes, so a favorable association cannot establish that a particular joint caused an improvement.

Of 34 family/sequence pairs separated at least once, 1 had at least 24 informative comparisons across eight or more calibration parents. Below are up to five positive and five negative associations meeting that exposure requirement. The full CSV retains rare cases. Positive and negative parent counts use a 0.012 margin. Absence of an informative pair means the intervention did not separate that sequence in this cohort.

| Family | Joint word | Informative pairs | Parents, positive / negative | Mean difference |
| --- | --- | ---: | ---: | ---: |
| crossing-ribbons | turn 0.1 | 52 | 9, 9 / 0 | +0.057 |

Turn words preserve two consecutive turns (0 straight, 1 counterclockwise eighth-turn, 2 quarter-turn, 6 clockwise quarter-turn, 7 clockwise eighth-turn). Fork words list incoming and outgoing ray masks around one incoming ray; bit 4 of the outgoing mask continues straight. Repetition of the same shape in two arms is not counted. [All comparisons](joint-paired.csv).
